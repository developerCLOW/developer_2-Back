<?= $this->extend('template/admin') ?>
<?= $this->section('content') ?>

<div class="col">
    <?php
        if (!empty(session()->getFlashdata('info'))) {
            echo '<div class="alert alert-danger" role="alert">';
            echo session()->getFlashdata('info');
            echo '</div>';
        } 
    ?>
</div>

<div class="row mb-2">
    <div class="col-sm-6">
        <h1 class="m-0 text-dark"><strong>Tambah Kategori</strong></h1>
    </div>
    <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?= base_url() ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url() ?>/admin/kategori">Kategori</a></li>
            <li class="breadcrumb-item active">Tambah Kategori</li>
        </ol>
    </div>
</div>

<div class="col-12">
    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">Form Kategori</h3>
        </div>
        <!-- /.card-header -->
        <!-- form start -->
        <form action="<?= base_url('/admin/kategori/insert') ?>" method="post">
            <div class="card-body">
                <div class="form-group">
                    <label for="Icon">Icon</label>
                    <input type="text" name="logo" class="form-control" id="Icon" placeholder="Masukkan Code Icon | Ex: fas fa-user" required>
                </div>
                <div class="form-group">
                    <label for="Kategori">Kategori</label>
                    <input type="text" name="kategori" class="form-control" id="Kategori" placeholder="Masukkan Kategori" required>
                </div>
                <div class="form-group">
                    <label for="Keterangan">Keterangan</label>
                    <textarea class="form-control" name="keterangan" rows="3" placeholder="Tambahkan Keterangan"></textarea required>
                </div>
            </div>
            <!-- /.card-body -->

            <div class="card-footer">
                <button type="submit" class="btn btn-primary">Tambahkan</button>
            </div>
        </form>
    </div>
</div>

<?= $this->endSection() ?>