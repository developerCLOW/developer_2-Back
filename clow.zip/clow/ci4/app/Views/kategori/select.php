<?= $this->extend('template/admin') ?>
<?= $this->section('content') ?>

<div class="row mb-2">
    <div class="col-sm-6">
        <h1 class="m-0 text-dark"><strong>Kategori Artikel</strong></h1>
    </div>
    <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?= base_url() ?>">Home</a></li>
            <li class="breadcrumb-item active">Kategori</li>
        </ol>
    </div>
</div>

<div class="row mt-2">
    <div class="col">
        <div class="card card-primary card-outline">
            <div class="card-body">
                <a href="<?= base_url('/admin/kategori/create') ?>" class="btn btn-primary mb-3" role="button">Tambah Kategori</a>
                <table id="example2" class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Icon</th>
                            <th>Kategori</th>
                            <th>Keterangan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1 ?>
                        <?php foreach($kategori as $key => $value): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $value['logo'] ?></td>
                            <td><?= $value['kategori'] ?></td>
                            <td><?= $value['keterangan'] ?></td>
                            <td>
                                <a href="<?= base_url() ?>/admin/kategori/delete/<?= $value['idkategori'] ?>"><i class="mr-2 fas fa-trash"></i></a>
                                <a href="<?= base_url() ?>/admin/kategori/find/<?= $value['idkategori'] ?>"><i class="fas fa-edit"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                  </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>